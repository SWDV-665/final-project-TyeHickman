// Set up
var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var cors = require('cors');

// Configuration
mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/mySelf");

app.use(bodyParser.urlencoded({'extended': 'true'}));
app.use(bodyParser.json());
app.use(bodyParser.json({type: 'application/vnd.api+json'}));
app.use(methodOverride());
app.use(cors());

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'DELETE, POST, PUT');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// Model
var Habit = mongoose.model('Habit', {
    habitName: String,
    habitType: String,
    Occurences: Number
});


// Get all grocery items
app.get('/api/habits', function (req, res) {

    console.log("Listing habits items...");

    //use mongoose to get all habits in the database
    Habit.find(function (err, habits) {

        // if there is an error retrieving, send the error. nothing after res.send(err) will execute
        if (err) {
            res.send(err);
        }

        res.json(habits); // return all habits in JSON format
    });
});

// Get a habit item
app.get('/api/habits/:id', function(req, res) {
    console.log("Getting habit item " + req.params.id);

    Habit.findById(req.params.id, function (err, habit) {

        if (err) {
            res.send(err);
        }

        res.json(habit);
    })
});

// Create a habit Item
app.post('/api/habits', function (req, res) {

    console.log("Creating habit item...");

    Habit.create({
        habitName: req.body.habitName,
        habitType: req.body.habitType,
        Occurences: 0,
        done: false
    }, function (err, habit) {
        if (err) {
            res.send(err);
        }

        // create and return all the habits
        Habit.find(function (err, habits) {
            if (err)
                res.send(err);
            res.json(habits);
        });
    });

});

// Update a habit Item
app.put('/api/habits/:id', function (req, res) {
    const habit = {
        habitName: req.body.habitName,
        habitType: req.body.habitType,
        Occurences: req.body.Occurences
    };
    console.log("Updating item - ", req.params.id);
    Habit.update({_id: req.params.id}, habit, function (err, raw) {
        if (err) {
            res.send(err);
        }
        res.send(raw);
    });
});


// Delete a habit Item
app.delete('/api/habits/:id', function (req, res) {
    Habit.remove({
        _id: req.params.id
    }, function (err, habit) {
        if (err) {
            console.error("Error deleting habit ", err);
        }
        else {
            Habit.find(function (err, habits) {
                if (err) {
                    res.send(err);
                }
                else {
                    res.json(habits);
                }
            });
        }
    });
});


// Start app and listen on port 8080  
app.listen(process.env.PORT || 8080);
console.log("mySelf server listening on port  - ", (process.env.PORT || 8080));